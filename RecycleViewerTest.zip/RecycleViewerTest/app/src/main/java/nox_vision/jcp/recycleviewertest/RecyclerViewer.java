package nox_vision.jcp.recycleviewertest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.pm.ActivityInfo;
import android.os.Bundle;

public class RecyclerViewer extends AppCompatActivity {
    String Pid, UpcData;
    int Amt, Qty;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_viewer);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        int count = 10;
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        DataAdapter testAdapter = new DataAdapter();
        recyclerView.setAdapter(testAdapter);
        Data[] data = new Data[count];
        Pid = "Name";
        Amt = 20;
        Qty = 19;
        UpcData = "UPC Label";
        data[0] = new Data(Pid, Amt, Qty, UpcData);
        data[1] = new Data(Pid, Amt, Qty, UpcData);
        data[2] = new Data(Pid, Amt, Qty, UpcData);
        data[3] = new Data(Pid, Amt, Qty, UpcData);
        data[4] = new Data(Pid, Amt, Qty, UpcData);
        data[5] = new Data(Pid, Amt, Qty, UpcData);
        data[6] = new Data(Pid, Amt, Qty, UpcData);
        data[7] = new Data(Pid, Amt, Qty, UpcData);
        data[8] = new Data(Pid, Amt, Qty, UpcData);
        data[9] = new Data(Pid, Amt, Qty, UpcData);
        testAdapter.setListdata(data);
        testAdapter.notifyDataSetChanged();
    }
}
class Data{
    String pID;
    int QTY;
    int amt;
    String UPCData;
    public Data(String Pid, int Amt, int Qty, String UpcData) {
        this.pID = Pid;
        this.amt = Amt;
        this.QTY = Qty;
        this.UPCData = UpcData;
    }
}